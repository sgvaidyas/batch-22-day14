﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22Day14
{
    class Employee
    {
        public string Empname, Department;
        public float sal;

        public Employee()
        {
            Console.WriteLine("Enter Employee Name = ");
            Empname = Console.ReadLine();

            Console.WriteLine("Enter Employee Department = ");
            Department = Console.ReadLine();

            Console.WriteLine("Enter Employee Salary = ");
            sal = float.Parse(Console.ReadLine());
                       
        }

        public void display()
        {
            Console.WriteLine(Empname.PadLeft(20) + " | " + Department.PadLeft(20) +"|" + sal.ToString().PadLeft(20) );
        }
        public string outputstring()
        {
            return (Empname.PadLeft(20) + " | " + Department.PadLeft(20) + "|" + sal.ToString().PadLeft(20));
        }

    }
}
