﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22Day14
{
    class Program
    {
        static void Main(string[] args)
        {

            string ob = "Apple";
            string ob1 = ob;
            Console.WriteLine("String ob = "+ob);
            Console.WriteLine("String ob1 =" + ob1);

            object ob2 = ob.Clone();
            Console.WriteLine("object = " + ob2);

            Console.WriteLine(ob==ob1);
            Console.WriteLine(ob1==ob2);

            string ob3 = "Mango";
            Console.WriteLine(ob.CompareTo(ob1));
            Console.WriteLine(ob.CompareTo(ob3));
            Console.WriteLine(ob3.CompareTo(ob));


            string ob4 = "Orange";

           
            string newob = string.Concat(ob, ob1);

            Console.WriteLine(newob);


            // Console.WriteLine("a = "+ a.ToString());
            // Console.WriteLine("b = "  +b.ToString());

            string ob5 = "this is a string example";

            Console.WriteLine(ob5.Contains("example"));




            int[] arr = { 11, 22, 33, 44, 55 };
            String separator = "*";
            string result = "";
            result += String.Join(separator, arr);
            Console.WriteLine("Res = "+ result);


            string ob6 = "APPLE";
            Console.WriteLine(ob6.ToLower());
            string ob7 = "flower";
            Console.WriteLine(ob7.ToUpper());


            string s1 = "                    hey this              is                     ";
            s1=s1.Trim();
            Console.WriteLine(s1+ " is the string");



            string s2 = "BATCHMVC 22";
            Console.WriteLine(s2.StartsWith("BAy"));
            Console.WriteLine(s2.EndsWith("22"));


            string s3 = "apple";
            s3 = s3.PadLeft(10);
            Console.WriteLine(s3);

            s3 = s3.PadRight(15);
            Console.WriteLine(s3+ " hhhhhhh  ");

            string s4 = "hey this is my statement";
            Console.WriteLine(s4.IndexOf('i'));

            string s5 = s4.Remove(6);
            Console.WriteLine(s5);


            string[] newstring = s4.Split();
            foreach(string x in newstring)
                Console.WriteLine(x);



            string s6 = s4.Replace('i', 't');

            Console.WriteLine(s6);


            char[] a = new char[] { 'a', 'n', 'g', 'l', 'e' };
            char[] b = new char[] { 'b', 'a', 't' };


            string s7 = new string(a);
            Console.WriteLine(a);
            

        }
    }
}
