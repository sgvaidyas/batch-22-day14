﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22Day14
{
    class Program2
    {
        static void Main(string[] args)
        {

            List<Employee> emplrec = new List<Employee>();
            int ch;

            string filename = @"C:\Users\User\Desktop\myfile1.txt";
            do
            {
                Console.WriteLine("1 Insert employee record");
                Console.WriteLine("2 Display ");
                Console.WriteLine("3 Write to file");
                Console.WriteLine("4 Search -> Read from file");
                Console.WriteLine("5 Exit");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1: Employee emp = new Employee();
                        emplrec.Add(emp);
                        break;
                    case 2: foreach (Employee e in emplrec)
                        {
                            e.display();
                        }
                        break;
                    case 3:
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename))
                            {
                                foreach (Employee e in emplrec)
                                {

                                    writer.Write(e.outputstring() + "\n");
                                }

                            }                                                      

                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                         break;

                    case 4: Console.WriteLine("Enter the name of the Employee");
                        string name = Console.ReadLine();
                        try
                        {
                            string line;
                            using (StreamReader reader = new StreamReader(filename))
                            {
                               while( (line=reader.ReadLine()) !=null )
                                {
                                    if(line.Contains(name))
                                        Console.WriteLine("Record = \n"+line);
                                }
                            }

                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }

                        break;
                    case 5: break;
                    default: Console.WriteLine("invalid choice"); break;
                }
            } while (ch!=5);
        }
    }
}
