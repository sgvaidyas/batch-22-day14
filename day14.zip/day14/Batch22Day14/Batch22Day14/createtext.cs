﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22Day14
{
    class createtext
    {
        static void Main(string[] args)
        {

            List<Employee> emp = new List<Employee>();

            string filename = @"C:\Users\User\Desktop\sample1.txt";
            FileInfo file = new FileInfo(filename);

            StreamWriter ob = file.CreateText();
            int flag = 1;
            while(flag<=3)
            {
                Employee e = new Employee();
                emp.Add(e);
                flag++;
            }
            flag = 1;
            
            foreach(Employee e in emp)
            {
                ob.WriteLine(e.outputstring());
            }
            ob.Close();

        }
    }
}
