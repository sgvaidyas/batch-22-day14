﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22Day14
{
    class filedata
    {
        static void Main(string[] args)
        {
            string filename = @"C:\Users\User\Desktop\myfile7.txt";

            string[] lines = new string[5];

            for(int i=0;i<5;i++)
            {
                Console.WriteLine("Enter string for {0} pos = " ,i);
                lines[i] = Console.ReadLine();
            }

            File.WriteAllLines(filename, lines);

        }
    }
}
