﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22Day14
{
    class streamreaderex
    {
        static void Main(string[] args)
        {

            string filename = @"C:\Users\User\Desktop\myfile.txt";
            string line;
            try
            {
                StreamReader ob = new StreamReader(filename);
                while((line = ob.ReadLine())!=null)
                {
                    Console.WriteLine(line);
                }
            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }
    }
}
