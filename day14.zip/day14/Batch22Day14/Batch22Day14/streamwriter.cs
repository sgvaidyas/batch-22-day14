﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22Day14
{
    class streamwriter
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            string filename = @"C:\Users\User\Desktop\myfile2.txt";

           // FileStream file = new FileStream(filename,FileMode.OpenOrCreate);
            try
            {
                StreamWriter writer = new StreamWriter(filename, true);
                
                writer.Write(emp.outputstring()+"\n");
                
            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }
    }
}
